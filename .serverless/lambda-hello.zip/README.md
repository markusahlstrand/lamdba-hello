# lamdba-hello
A minimal lambda app for testing purposes
