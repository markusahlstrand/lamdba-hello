var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'markusahlstrand',
applicationName: 'lamdba-hello',
appUid: 'kXxFqYSLRGqLVNJm0h',
tenantUid: 'rRzcDTMGT0sNMlW8Tb',
deploymentUid: '8da17f69-3ed2-481a-9ee7-14906921e26b',
serviceName: 'lambda-hello',
stageName: 'dev',
pluginVersion: '3.1.2'})
const handlerWrapperArgs = { functionName: 'lambda-hello-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
